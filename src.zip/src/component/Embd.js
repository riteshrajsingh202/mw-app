
function Embd() {
    
    return <div>
    
  </div>;
}
export default Embd