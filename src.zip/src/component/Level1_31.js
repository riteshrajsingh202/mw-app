import React from 'react'
import '../App.css';
export default function Level1_31() {
  return (
    <div className='secondscreen'>
      <iframe width="100%" height="100%" src="https://public.tableau.com/views/PublicSectorEmergencyCallsDashboardB2VBRWFD/Overview?:language=en-US&:display_count=n&:origin=viz_share_link&amp;:showVizHome=no&amp;:embed=true;&hideTabs:true">
  </iframe>
  </div>
  )
}
