import React from 'react';
import '../App.css';
export default function Embedded() {
  return (
    <div>
        <div className="App_2">
    <iframe title="any" width="24%" height="100%" src="https://app.powerbi.com/reportEmbed?reportId=603dd7bc-8e5f-450e-a77e-9b845660e7d3&autoAuth=true&ctid=189de737-c93a-4f5a-8b68-6f4ca9941912&filterPaneEnabled=false&navContentPaneEnabled=false" ></iframe>
    <iframe width="25%" height="100%" src="https://public.tableau.com/views/WOW202246-Maps/Dashboard1?:language=en-US&:display_count=n&:origin=viz_share_link&amp;:showVizHome=no&amp;:embed=true;&hideTabs:true">
  </iframe>
  <iframe width="24%" height="100%" src="https://public.tableau.com/views/PublicSectorEmergencyCallsDashboardB2VBRWFD/Overview?:language=en-US&:display_count=n&:origin=viz_share_link&amp;:showVizHome=no&amp;:embed=true">
  </iframe>
  <iframe width="25%" height="100%" src="https://public.tableau.com/views/WOW202246-Maps/Dashboard1?:language=en-US&:display_count=n&:origin=viz_share_link&amp;:showVizHome=no&amp;:embed=true">
  </iframe>
  
  </div>
  <div className="App_3">
  <iframe title="any" width="24%" height="100%" src="https://app.powerbi.com/reportEmbed?reportId=603dd7bc-8e5f-450e-a77e-9b845660e7d3&autoAuth=true&ctid=189de737-c93a-4f5a-8b68-6f4ca9941912&filterPaneEnabled=false&navContentPaneEnabled=false" ></iframe>
    <iframe width="25%" height="100%" src="https://public.tableau.com/views/WOW202246-Maps/Dashboard1?:language=en-US&:display_count=n&:origin=viz_share_link&amp;:showVizHome=no&amp;:embed=true">
  </iframe>
  <iframe width="24%" height="100%" src="https://public.tableau.com/views/PublicSectorEmergencyCallsDashboardB2VBRWFD/Overview?:language=en-US&:display_count=n&:origin=viz_share_link&amp;:showVizHome=no&amp;:embed=true">
  </iframe>
  <iframe width="25%" height="100%" src="https://public.tableau.com/views/WOW202246-Maps/Dashboard1?:language=en-US&:display_count=n&:origin=viz_share_link&amp;:showVizHome=no&amp;:embed=true">
  </iframe>
  </div>
  <div className="App_4">
  <iframe title="any" width="24%" height="100%" src="https://app.powerbi.com/reportEmbed?reportId=603dd7bc-8e5f-450e-a77e-9b845660e7d3&autoAuth=true&ctid=189de737-c93a-4f5a-8b68-6f4ca9941912&filterPaneEnabled=false&navContentPaneEnabled=false" ></iframe>
    <iframe width="25%" height="100%" src="https://public.tableau.com/views/WOW202246-Maps/Dashboard1?:language=en-US&:display_count=n&:origin=viz_share_link&amp;:showVizHome=no&amp;:embed=true">
  </iframe>
  <iframe width="24%" height="100%" src="https://public.tableau.com/views/PublicSectorEmergencyCallsDashboardB2VBRWFD/Overview?:language=en-US&:display_count=n&:origin=viz_share_link&amp;:showVizHome=no&amp;:embed=true">
  </iframe>
  <iframe width="25%" height="100%" src="https://public.tableau.com/views/WOW202246-Maps/Dashboard1?:language=en-US&:display_count=n&:origin=viz_share_link&amp;:showVizHome=no&amp;:embed=true">
  </iframe>
  </div>
  <div className="App_5">
  <iframe title="any" width="24%" height="100%" src="https://app.powerbi.com/reportEmbed?reportId=c5781ad6-becd-42c8-a923-170075a4feff&autoAuth=true&ctid=189de737-c93a-4f5a-8b68-6f4ca9941912&filterPaneEnabled=false&navContentPaneEnabled=false"></iframe>
    <iframe width="25%" height="100%" src="https://public.tableau.com/views/WOW202246-Maps/Dashboard1?:language=en-US&:display_count=n&:origin=viz_share_link&amp;:showVizHome=no&amp;:embed=true">
  </iframe>
  <iframe width="24%" height="100%" src="https://public.tableau.com/views/PublicSectorEmergencyCallsDashboardB2VBRWFD/Overview?:language=en-US&:display_count=n&:origin=viz_share_link&amp;:showVizHome=no&amp;:embed=true">
  </iframe>
  <iframe width="25%" height="100%" src="https://public.tableau.com/views/WOW202246-Maps/Dashboard1?:language=en-US&:display_count=n&:origin=viz_share_link&amp;:showVizHome=no&amp;:embed=true">
  </iframe>
  </div>
      
    </div>
  )
}
