import React from 'react';
import './App.css';
import Mainframe from './component/Mainframe';
// import Embedded from './component/Embedded';
// import Navigation from './component/Navigation';
function App() {
  const home = () => {
    window.location.reload()
};
  return (
    <div>
      {/* <div className="App_2">
      Basic Embbed<br></br>
      Click On Data Points To View In Details
      </div> */}
      {/* <div className="App_2">
        <Embedding/>
        </div> */}
        <div className="header">
          Management Dashboard
          <button className="homebutton" type="button" onClick={home}>Home</button>
        </div>
        {/* <div classname="main"> */}
          <Mainframe></Mainframe>
        {/* </div> */}
        
    {/* <Embedding/> */}
    </div>
    
  );
}

export default App;
